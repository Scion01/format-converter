from distutils.core import setup

setup(name='type_convert',version='1.0',py_modules=['main_script','convert_script'])

